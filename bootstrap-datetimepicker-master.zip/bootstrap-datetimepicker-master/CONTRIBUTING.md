Contributions guidelines:

- Use 2 spaces indentation
- If it is a bug, please read open issues to avoid duplicates
- If it is a new feature, please provide a use case. E.g. Why this feature should be added and what you are using it for
- If possible, please provide example code and/or a jdfiddle and a DETAILED example of what is not working
